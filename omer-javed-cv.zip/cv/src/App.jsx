import { useRef, useState } from "react";
import CertificateModal from "./CertificateModal.jsx";
import certificates from "./data/certificates.js";

/* The design is 2532 x 3508 px (from the PSD).
   Hotspots are placed in % of that size so they stay on the right spot at any screen width. */
const W = 2532;
const H = 3508;
const box = (x, y, w, h) => ({
  left: `${(x / W) * 100}%`,
  top: `${(y / H) * 100}%`,
  width: `${(w / W) * 100}%`,
  height: `${(h / H) * 100}%`,
});

export default function App() {
  const [open, setOpen] = useState(false);
  const triggerRef = useRef(null);

  const close = () => {
    setOpen(false);
    requestAnimationFrame(() => triggerRef.current && triggerRef.current.focus());
  };

  return (
    <main className="page">
      <article className="sheet" aria-label="Curriculum vitae of Muhammad Omer Javed">
        <img
          className="sheet-art"
          src="/cv/cv-design.jpg"
          srcSet="/cv/cv-design-1266.jpg 1266w, /cv/cv-design.jpg 2532w"
          sizes="(max-width: 980px) 100vw, 940px"
          width={W}
          height={H}
          alt=""
          aria-hidden="true"
          draggable="false"
        />

        {/* Certificates section: opens the slider */}
        <button
          ref={triggerRef}
          type="button"
          className="hot hot-certs"
          style={box(269, 2415, 1961, 297)}
          onClick={() => setOpen(true)}
          aria-haspopup="dialog"
          aria-label={`View certificates (${certificates.length})`}
        >
          <span className="seal" aria-hidden="true">
            <span className="seal-count">{certificates.length}</span>
            <span className="seal-label">View</span>
          </span>
          <span className="hot-hint" aria-hidden="true">Click to view</span>
        </button>

        {/* Contact links on the wooden roller */}
        <a className="hot hot-link" style={box(455, 3040, 630, 120)} href="tel:+923253926387" aria-label="Call +92 325 392 6387" />
        <a className="hot hot-link" style={box(1140, 3040, 925, 120)} href="mailto:tamagency2@gmail.com" aria-label="Email tamagency2@gmail.com" />
        <a
          className="hot hot-link"
          style={box(330, 3175, 1810, 115)}
          href="https://www.google.com/maps/search/?api=1&query=Al-Khaleej+Tower+FB+Area+Block+8+Yaseenabad+Karachi"
          target="_blank"
          rel="noreferrer"
          aria-label="Open address in Google Maps: Al-Khaleej Tower, FB Area Block 8, Yaseenabad, Karachi"
        />

        {/* Real text of the CV for screen readers and search engines (hidden visually) */}
        <div className="sr-only">
          <h1>Muhammad Omer Javed</h1>
          <h2>Objective</h2>
          <p>
            To obtain a challenging position in a professional organization where I can utilize my skills, knowledge, and abilities to
            contribute to the growth of the organization while continuously developing my professional and personal skills.
          </p>
          <h2>Skills</h2>
          <p>HTML, CSS, Bootstrap, JavaScript, WordPress, JS React, Angular, Adobe Photoshop, Adobe InDesign, Adobe Illustrator, Canva Pro AI</p>
          <h2>Experience</h2>
          <p>Goyzer: Graphic Designer, Web Designer, Web Developer.</p>
          <ul>
            <li>Designed creative graphics, branding, and social media content.</li>
            <li>Created modern, responsive, and user-friendly website designs.</li>
            <li>Developed, maintained, and optimized responsive websites.</li>
            <li>Collaborated with the team to deliver high-quality projects on time.</li>
          </ul>
          <h2>Education</h2>
          <p>Bachelor's Degree in Fine Arts, Karachi University (2009–2013)</p>
          <h2>Certificates</h2>
          <ul>
            {certificates.map((c) => (
              <li key={c.file}>
                {c.title}, {c.issuer}, {c.date}
              </li>
            ))}
          </ul>
          <h2>References</h2>
          <p>Available upon request.</p>
          <h2>Contact</h2>
          <p>Phone: +92 325 392 6387. Email: tamagency2@gmail.com. Address: Al-Khaleej Tower, FB Area Block 8, Yaseenabad, Karachi.</p>
        </div>
      </article>

      {open && <CertificateModal items={certificates} onClose={close} />}
    </main>
  );
}
