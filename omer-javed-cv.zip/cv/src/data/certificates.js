// Newest first. Images live in /public/certificates.
// To add one: drop "name.jpg" and "name-thumb.jpg" in that folder and add a row here.
const certificates = [
  { file: "studysection-html-css", title: "HTML & CSS (Foundation)", issuer: "StudySection E-Certification Center", date: "27 Dec 2023" },
  { file: "aptech-dreamweaver", title: "Designing Websites in Dreamweaver 8.0", issuer: "Aptech Computer Education", date: "28 Jun 2014" },
  { file: "alison-powerpoint-2010", title: "Microsoft PowerPoint 2010", issuer: "ALISON", date: "11 Apr 2013" },
  { file: "alison-excel-2010", title: "Microsoft Excel 2010", issuer: "ALISON", date: "23 Dec 2012" },
  { file: "alison-outlook-2010", title: "Microsoft Outlook 2010", issuer: "ALISON", date: "09 Dec 2012" },
  { file: "alison-word-2010", title: "Microsoft Word 2010", issuer: "ALISON", date: "05 Dec 2012" },
  { file: "alison-sketchup", title: "Google SketchUp for 3D Modeling", issuer: "ALISON", date: "28 Nov 2012" },
  { file: "alison-design-principles", title: "Design: Applying Design Principles", issuer: "ALISON", date: "26 Nov 2012" },
  { file: "alison-graphic-design", title: "Graphic Design: Visual and Graphic Design", issuer: "ALISON", date: "25 Nov 2012" },
  { file: "alison-photoshop-cs6", title: "Adobe Photoshop CS6 Essential Tools", issuer: "ALISON", date: "25 Nov 2012" },
  { file: "pacc-graphics-software", title: "CorelDRAW, Flash, Photoshop, Illustrator & InDesign Programme", issuer: "Professional Academy of Computer Career (PACC)", date: "28 Jun 2010" },
  { file: "pacc-windows-ms-office", title: "Windows XP, MS Office & Internet Programme", issuer: "Professional Academy of Computer Career (PACC)", date: "28 Jun 2010" },
  { file: "abc-networking", title: "Networking (Windows 2000 Server)", issuer: "Academy of Business Computers (ABC)", date: "23 Feb 2008" },
  { file: "pak-american-english", title: "English Language Course, Levels One to Three", issuer: "Pak American Institute", date: "15 Jan 2008" },
  { file: "pacc-diploma-graphics-web", title: "Diploma in Graphics & Web Development", issuer: "Professional Academy of Computer Career (PACC)", date: "02 Aug 2007" },
  { file: "mafhh-ms-office", title: "MS Office & Internet Course", issuer: "MAFHH Institute of IT", date: "09 Sep 2003" },
];

export default certificates;
