import { useCallback, useEffect, useRef, useState } from "react";

const src = (c) => `/certificates/${c.file}.jpg`;
const thumb = (c) => `/certificates/${c.file}-thumb.jpg`;

export default function CertificateModal({ items, onClose, startIndex = 0 }) {
  const [index, setIndex] = useState(startIndex);
  const [dir, setDir] = useState(1);
  const dialogRef = useRef(null);
  const closeRef = useRef(null);
  const thumbsRef = useRef(null);
  const touch = useRef(null);
  const count = items.length;
  const item = items[index];

  const go = useCallback(
    (step) => {
      setDir(step);
      setIndex((i) => (i + step + count) % count);
    },
    [count]
  );
  const jump = (i) => {
    setDir(i > index ? 1 : -1);
    setIndex(i);
  };

  // focus, scroll lock, keyboard
  useEffect(() => {
    closeRef.current && closeRef.current.focus();
    const prevOverflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    const onKey = (e) => {
      if (e.key === "Escape") onClose();
      else if (e.key === "ArrowRight") go(1);
      else if (e.key === "ArrowLeft") go(-1);
      else if (e.key === "Tab" && dialogRef.current) {
        const f = dialogRef.current.querySelectorAll("button");
        const first = f[0];
        const last = f[f.length - 1];
        if (e.shiftKey && document.activeElement === first) {
          e.preventDefault();
          last.focus();
        } else if (!e.shiftKey && document.activeElement === last) {
          e.preventDefault();
          first.focus();
        }
      }
    };
    window.addEventListener("keydown", onKey);
    return () => {
      window.removeEventListener("keydown", onKey);
      document.body.style.overflow = prevOverflow;
    };
  }, [go, onClose]);

  // keep the active thumbnail in view and preload neighbours
  useEffect(() => {
    const el = thumbsRef.current && thumbsRef.current.children[index];
    if (el) el.scrollIntoView({ block: "nearest", inline: "center", behavior: "smooth" });
    [index + 1, index - 1].forEach((i) => {
      const img = new Image();
      img.src = src(items[(i + count) % count]);
    });
  }, [index, items, count]);

  const onTouchStart = (e) => (touch.current = e.touches[0].clientX);
  const onTouchEnd = (e) => {
    if (touch.current == null) return;
    const dx = e.changedTouches[0].clientX - touch.current;
    if (Math.abs(dx) > 40) go(dx < 0 ? 1 : -1);
    touch.current = null;
  };

  return (
    <div className="cm-backdrop" onMouseDown={(e) => e.target === e.currentTarget && onClose()}>
      <div className="cm-dialog" role="dialog" aria-modal="true" aria-labelledby="cm-title" ref={dialogRef}>
        <header className="cm-head">
          <div>
            <p className="cm-kicker">Certificates</p>
            <h2 id="cm-title">{item.title}</h2>
            <p className="cm-meta">
              {item.issuer} <span aria-hidden="true">·</span> {item.date}
            </p>
          </div>
          <button ref={closeRef} type="button" className="cm-close" onClick={onClose} aria-label="Close certificates">
            <svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" strokeWidth="2.4" strokeLinecap="round">
              <path d="M6 6l12 12M18 6L6 18" />
            </svg>
          </button>
        </header>

        <div className="cm-stage" onTouchStart={onTouchStart} onTouchEnd={onTouchEnd}>
          <button type="button" className="cm-arrow prev" onClick={() => go(-1)} aria-label="Previous certificate">
            <svg viewBox="0 0 24 24" width="26" height="26" fill="none" stroke="currentColor" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round">
              <path d="M15 5l-7 7 7 7" />
            </svg>
          </button>

          <figure className="cm-figure">
            <img key={item.file} className={`cm-img ${dir > 0 ? "from-right" : "from-left"}`} src={src(item)} alt={`${item.title}, ${item.issuer}, ${item.date}`} />
          </figure>

          <button type="button" className="cm-arrow next" onClick={() => go(1)} aria-label="Next certificate">
            <svg viewBox="0 0 24 24" width="26" height="26" fill="none" stroke="currentColor" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round">
              <path d="M9 5l7 7-7 7" />
            </svg>
          </button>

          <p className="cm-counter" aria-live="polite">
            {index + 1} / {count}
          </p>
        </div>

        <footer className="cm-roller">
          <div className="cm-thumbs" ref={thumbsRef}>
            {items.map((c, i) => (
              <button
                key={c.file}
                type="button"
                className={`cm-thumb${i === index ? " on" : ""}`}
                onClick={() => jump(i)}
                aria-label={`Show ${c.title}`}
                aria-current={i === index ? "true" : undefined}
              >
                <img src={thumb(c)} alt="" loading="lazy" />
              </button>
            ))}
          </div>
        </footer>
      </div>
    </div>
  );
}
