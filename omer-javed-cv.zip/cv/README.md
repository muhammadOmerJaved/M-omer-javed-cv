# Muhammad Omer Javed – CV (React + Vite)

## Run it
```bash
npm install
npm start
```
Then open the address it prints (usually http://localhost:5173).

## How it's built
- `public/cv/cv-design.jpg` is the CV artwork exported from the PSD (2532 x 3508), shown centred.
- Clickable areas sit on top of it in `src/App.jsx`:
  - Certificates section → opens the certificate slider
  - Phone, email and address on the wooden roller → call, email, Google Maps
- The full CV text is also in the page (hidden visually) for screen readers and Google.

## Certificates
Images are in `public/certificates/` (`name.jpg` + `name-thumb.jpg`).
The list, titles and dates are in `src/data/certificates.js`. Add or remove rows there.

## Build for a website
```bash
npm run build
```
Upload the `dist` folder to your hosting.
